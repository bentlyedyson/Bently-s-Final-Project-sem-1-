from tkinter import* 
import pygame 
import os 
from classess import Millionaire 

pygame.init()  

class App:
  def __init__(self, master):
    frame = Frame(master)
    frame.pack()
    self.button = Button(frame, 
                         text="QUIT", fg="red",
                         command=frame.quit)
    self.button.pack(side=LEFT)
    self.slogan = Button(frame,
                         text="Hello",
                         command=self.write_slogan)
    self.slogan.pack(side=LEFT)
  def write_slogan(self):
    print "Tkinter is easy to use!"
root = Tk()
ui = Millionaire(root)
#1st frame 
#-------------------------------------------FRAMES----------------------------------------------------------------------------------------------------------------------------------#
frame = Frame(root, bg='black')
frame.grid()

frame1 = Frame(root, bg='black', bd = 25, width = 900, height = 600)
frame1.grid(row = 0, column = 0 )

frame2 = Frame(root, bg='black', bd = 26, width = 452, height = 600)
frame2.grid(row = 0, column = 1 )

frame1a = Frame(frame1, bg='black', bd = 20, width = 900, height = 200)
frame1a.grid(row = 0, column = 0)

frame1b = Frame(frame1, bg='black', bd = 20, width = 900, height = 200)
frame1b.grid(row = 1, column = 0 )

frame1c = Frame(frame1, bg='black', bd = 21, width = 900, height = 200)
frame1c.grid(row = 2, column = 0 )
#--------------------------------------------FUNCTION-------------------------------------------------------------------------------------------------------------------------------#
def Change50_50():
    canvas = Canvas(frame1a, width = 200, height = 100)
    canvas.grid(row=0, column=0)
    canvas.delete("all")
    image1 = PhotoImage(file="images/50x.png")
    canvas.create_image(100,50, image = image1 )
    canvas.image = image1

def Change_People():
    canvas1 = Canvas(frame1a, width = 200, height = 100)
    canvas1.grid(row=0, column=1)
    canvas1.delete("all")
    image2 = PhotoImage(file="images/peoplex.png")
    canvas1.create_image(100,50, image = image2 )
    canvas1.image = image2

def ChangePhone():
    canvas2 = Canvas(frame1a, width = 200, height = 100)
    canvas2.grid(row=0, column=2)
    canvas2.delete("all")
    image3 = PhotoImage(file="images/phonex.png")
    canvas2.create_image(100,50, image = image3 )
    canvas2.image = image3

def final_Mill():
    canvas18 = Canvas(frame1b, width = 300, height = 200)
    canvas18.grid(row=0, column=0)
    canvas18.delete("all")
    image19 = PhotoImage(file="images/Picture16.png")
    canvas18.create_image(150, 100, image = image19 )
    canvas18.image = image19

index = 0
images = ["Picture0.png","Picture01.png","Picture02.png","picture03.png","Picture04.png","Picture05.png",
            "Picture06.png","Picture07.png","Picture08.png","Picture09.png","Picture10.png",
            "Picture11.png","Picture12.png","Picture13.png","Picture14.png","Picture15.png"]
def Milli(index):
    canvas = Canvas(frame2, width = 340, height = 590)
    canvas.grid(row=0,column=2)
    canvas.delete("all")
    image = PhotoImage(file="images/" + images[index])
    canvas.create_image(170,295,image = image)
    canvas.image = image

#-------------------------------------------Images----------------------------------------------------------------------------------------------------------------------------------#
CentreImage = PhotoImage(file="images/Centre.png")                                                                                                                                 ##
LogoCentre = Button(frame1b, image= CentreImage, bg='black', width = 300, height = 200)                                                                                            ##
LogoCentre.grid()                                                                                                                                                                  ##
                                                                                                                                                                                   ##
Image50_50 = PhotoImage(file="images/50-50.png")                                                                                                                                   ##
Live50_50= Button(frame1a, image= Image50_50, bg='black', width = 200, height = 100, command = Change50_50)                                                                        ##
Live50_50.grid(row=0, column=0)                                                                                                                                                    ##
                                                                                                                                                                                   ##
                                                                                                                                                                                   ##
ImagePeople = PhotoImage(file="images/People.png")                                                                                                                                 ##                                         
LivePeople= Button(frame1a, image= ImagePeople, bg='black', width = 200, height = 100, command = Change_People)                                                                    ## 
LivePeople.grid(row=0, column=1)                                                                                                                                                   ##     
                                                                                                                                                                                   ##
                                                                                                                                                                                   ##
ImagePhone = PhotoImage(file="images/Phone.png")                                                                                                                                   ##               
LivePhone= Button(frame1a, image= ImagePhone, bg='black', width = 200, height = 100, command = ChangePhone)                                                                        ##         
LivePhone.grid(row=0, column=2)                                                                                                                                                    ##         
                                                                                                                                                                                   ##    
#Page of the millionaire count                                                                                                                                                     ##         
M0 = PhotoImage(file="images/Picture0.png")                                                                                                                                        ##
M00= Label(frame2, image= M0, bg='black', width = 340, height = 595)                                                                                                               ##
M00.grid(row=0, column=2)                                                                                                                                                          ##
#-------------------------------------------QUESTION--------------------------------------------------------------------------------------------------------------------------------#
Question_1 = StringVar()

Answer_1 = StringVar()
Answer_2 = StringVar()
Answer_3 = StringVar()
Answer_4 = StringVar()

def Question_one():
    global index
    Question_1.set(" What is 2 + 32")
    Answer_1.set("22")
    Answer_2.set("26")
    Answer_3.set("31")
    Answer_4.set("34")
    index+=1
    Question2= Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_4, command = Question_2)
    Question2.grid(row=2, column=3)
def Question_2():
    global index
    Question_1.set("What is 8 x 2")
    Answer_1.set("16")
    Answer_2.set("18")
    Answer_3.set("3")
    Answer_4.set("54")
    Milli(index)
    index += 1
    Question3 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_1, command = Question_3)
    Question3.grid(row=1, column=1)
def Question_3():
    global index
    Question_1.set(" What is 2 + 12")
    Answer_1.set("22")
    Answer_2.set("26")
    Answer_3.set("14")
    Answer_4.set("34")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_3, command = Question_4)
    Question6.grid(row=2, column=1)
def Question_4():
    global index
    Question_1.set("What is 2 + 2")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("1")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_2, command = Question_5)
    Question6.grid(row=1, column=3)
def Question_5():
    global index
    Question_1.set("What is 2 + 1")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("3")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_3, command = Question_6)
    Question6.grid(row=2, column=1)
def Question_6():
    global index
    Question_1.set("What is 2 + 0")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("1")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_4, command = Question_7)
    Question6.grid(row=2, column=3)
def Question_7():
    global index
    Question_1.set("What is 2 + 2")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("1")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_2, command = Question_8)
    Question6.grid(row=1, column=3)
def Question_8():
    global index
    Question_1.set("What is 4 + 2")
    Answer_1.set("6")
    Answer_2.set("4")
    Answer_3.set("1")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_1, command = Question_9)
    Question6.grid(row=1, column=1)
def Question_9():
    global index
    Question_1.set("What is 2/ 2")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("1")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_3, command = Question_10)
    Question6.grid(row=2, column=1)
def Question_10():
    global index
    Question_1.set("What is 2 x 2")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("1")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_2, command = Question_11)
    Question6.grid(row=1, column=3)
def Question_11():
    global index
    Question_1.set("What is 5 +  2")
    Answer_1.set("22")
    Answer_2.set("7")
    Answer_3.set("1")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_2, command = Question_12)
    Question6.grid(row=1, column=3)
def Question_12():
    global index
    Question_1.set("What is 7 x 2")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("14")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_3, command = Question_13)
    Question6.grid(row=2, column=1)
def Question_13():
    global index
    Question_1.set("What is 7 x 3")
    Answer_1.set("Big shaq")
    Answer_2.set("4")
    Answer_3.set("14")
    Answer_4.set("21")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_4, command = Question_14)
    Question6.grid(row=2, column=3)
def Question_14():
    global index
    Question_1.set("What is 7 x 7")
    Answer_1.set("49")
    Answer_2.set("4")
    Answer_3.set("14")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_1, command = Question_15)
    Question6.grid(row=1, column=1)
def Question_15():
    global index
    Question_1.set("What is 7 x 8")
    Answer_1.set("0")
    Answer_2.set("4")
    Answer_3.set("56")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_3, command = Question_16)
    Question6.grid(row=2, column=1)
def Question_16():
    global index
    Question_1.set("What is 7 x 6")
    Answer_1.set("0")
    Answer_2.set("4")
    Answer_3.set("42")
    Answer_4.set("2")
    Milli(index)
    index+=1
    Question6 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_3, command = seventeen)
    Question6.grid(row=2, column=1)

#-------------------------------------------##--------------------------------------------------------------------------------------------------------------------------------------#

Question= Label(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=5, width=44, justify= CENTER, textvariable = Question_1)
Question.grid(row=0, column=0, columnspan = 4, pady = 4 ) 

#-----------------------------------------Choices-----------------------------------------------------------------------------------------------------------------------------------#
A = Label(frame1c, font=('arial', 14, 'bold'),text = "A: " ,bg='black', fg='white', bd='5', justify= CENTER)
A.grid(row=1, column=0, pady = 4, sticky = W)

Question= Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_1, command = quit)
Question.grid(row=1, column=1) 

B = Label(frame1c, font=('arial', 14, 'bold'),text = "B: " ,bg='black', fg='white',justify= LEFT)
B.grid(row=1, column=2, sticky = W) 

Question1 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_2, command = quit)
Question1.grid(row=1, column=3) 

C = Label(frame1c, font=('arial', 14, 'bold'),text = "C: " ,bg='black', fg='white',justify= LEFT)
C.grid(row=2, column=0, sticky = W) 

Question2 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_3, command = quit)
Question2.grid(row=2, column=1) 

D = Label(frame1c, font=('arial', 14, 'bold'),text = "D: " ,bg='black', fg='white',justify= LEFT)
D.grid(row=2, column=2, sticky = W) 

Question3 = Button(frame1c, font=('arial', 14, 'bold'), bg='blue', fg='white', bd=1, width=17, height=2, justify= CENTER, textvariable = Answer_4, command = quit)
Question3.grid(row=2, column=3, pady = 4 ) 

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
def seventeen():
    final_Mill()
Question_one()
root.mainloop()