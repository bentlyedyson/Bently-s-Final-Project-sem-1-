class Millionaire():
    
    def __init__(self,root):
        def root():
            root = Tk()
            root.title("who wants to be a millionaire")
            root.geometry('1452x752+0+0')
            root.configure(background ='black')
